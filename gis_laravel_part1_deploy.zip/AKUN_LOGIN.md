# Kredensial Akun (UNTUK PENGEMBANGAN / UJI COBA)

> ⚠️ JANGAN commit file ini ke repositori publik. Untuk produksi, ganti semua password.

| Role | Nama | Email | Password |
|------|------|-------|----------|
| Super Admin | Super Admin | `superadmin@admin.com` | `Superadmin@1234` |
| Admin | Admin | `admin@admin.com` | `Admin@1234` |
| User Biasa | User Biasa | `user@user.com` | `User@1234` |

## Perbedaan Hak Akses

- **Super Admin** — semua fitur admin + kelola user & role + activity log (`/super-admin/*`)
- **Admin** — kelola lokasi/kategori/review/pengaturan, hanya bisa lihat role `user` di user management (`/admin/*`)
- **User Biasa** — hanya bisa melihat peta, review, favorit, navigasi

## Ganti Password

```bash
php artisan admin:reset-password <password_baru> --email=<email>
```

## Login

- Super Admin: `http://127.0.0.1:8010/login`
- Admin: `http://127.0.0.1:8010/login`
- User Biasa: `http://127.0.0.1:8010/login`
